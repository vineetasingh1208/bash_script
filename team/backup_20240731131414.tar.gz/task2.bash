#!/bin/bash

for i in {1..7}
do
	touch $i
done
