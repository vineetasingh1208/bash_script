#!/bin/bash
if [ -e /home/error.txt ]
then
	echo "file exist"
else
	echo "file does not exist"
fi

